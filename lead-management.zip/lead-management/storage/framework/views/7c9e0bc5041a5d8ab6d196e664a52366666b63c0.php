

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>

<div class="alert alert-info">
<?php echo e($message); ?>

</div>

<?php endif; ?>
<!-- <div class="row">
		<div class="col-md-12 text-center mb-5 punch-wrapper">
			<?php if(Auth::user()->punchin): ?>
				<p>Login Time: <?php echo e(Auth::user()->punchout); ?></p>
				<a href="<?php echo e(route('punch-out')); ?>" class="btn btn-danger">Punch Out</a>
			<?php else: ?>
            <div class="d-flex" style="justify-content: space-evenly;">
				<div>
                    <a href="<?php echo e(route('punch-in')); ?>" class="btn btn-warning punchin">Punchin</a>
                </div>
                <div>
                    <p id="punchin">logout Time: <?php echo e(Auth::user()->punchin); ?></p>
                </div>
            </div>
			<?php endif; ?>
		</div>
	</div> -->
<div class="card">
	
	<div class="card-body">
		<div class="row">
			
			<div class="col-md-12">
				<div class="col-md-8 group-button">
					<a href="<?php echo e(route('dashboard' )); ?>" class="btn btn-primary mt-3">Back to Dashboard</a>
				</div>     
			</div>
		</div>
		<div class="row mt-5">
			<div class="col-md-12">
				<table class="table table-bordered data-table">
					<thead>
						<tr>
							<th>No</th>
							<th>Date</th>
							<th>Punch In</th>
							<th>Punch Out</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
  $(function () {
    
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('showloginreports')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'att_date', name: 'att_date'},
            {data: 'punchin_time', name: 'punchin_time'},
            {data: 'punchout_time', name: 'punchout_time'},
        ]
    });
    
  });
</script>
<script>
	$( "#punchin" ).on( "click", function() {
		$(this).prop("disabled", true);
	} );
   function exportTasks(_this) {
      let _url = $(_this).data('href');
      window.location.href = _url;
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pgs-hrms\resources\views/showlogin.blade.php ENDPATH**/ ?>