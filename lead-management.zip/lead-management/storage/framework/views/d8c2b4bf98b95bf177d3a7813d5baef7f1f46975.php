

<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>

<div class="alert alert-info">
<?php echo e($message); ?>

</div>

<?php endif; ?>
<!-- <div class="row">
		<div class="col-md-12 text-center mb-5 punch-wrapper">
			<?php if(Auth::user()->punchin): ?>
				<p>Login Time: <?php echo e(Auth::user()->punchout); ?></p>
				<a href="<?php echo e(route('punch-out')); ?>" class="btn btn-danger">Punch Out</a>
			<?php else: ?>
            <div class="d-flex" style="justify-content: space-evenly;">
				<div>
                    <a href="<?php echo e(route('punch-in')); ?>" class="btn btn-warning punchin">Punchin</a>
                </div>
                <div>
                    <p id="punchin">logout Time: <?php echo e(Auth::user()->punchin); ?></p>
                </div>
            </div>
			<?php endif; ?>
		</div>
	</div> -->
<div class="card">
	<div class="row logintime-header">
		<div class="col-md-12 text-center mt-4 mb-4">
			<?php
				$id = Auth::id();
				$curr_att_date = date('Y-m-d H:i:s');
				$att_date = date('Y-m-d');
				$new_att_date = date('Y-m-d 06:59:59');
				
				if ($curr_att_date <= $new_att_date) {
					$att_date = date('Y-m-d', strtotime('-1 days'));
				}
				
				$attendanceDataNew = DB::select('SELECT * FROM attendances where user_id = '.$id.' AND att_date = "'.$att_date.'"');
			?>     

			<?php if(!empty($attendanceDataNew)): ?>
				<?php 
					$currentDateTime = $attendanceDataNew[0]->punchin_time;
					$newDateTime = date('g:i A', strtotime($currentDateTime));
				?>
				
					<div class="col-md-6 text-left">
						<span class="badge bg-dark">Punchin Time: <?php echo e($newDateTime); ?></span>
					</div>
					<div class="col-md-6 text-right">
						<a href="<?php echo e(route('userpunchout', base64_encode(Auth::id()))); ?>" class="btn btn-danger btn-rounded waves-effect waves-light mb-4">Punch Out</a>
					</div>
			
			<?php else: ?>
				<div align="center">
					<a href="<?php echo e(route('userpunchin', base64_encode(Auth::id()))); ?>" class="btn btn-success btn-rounded waves-effect waves-light">Punch In</a>
				</div>
			<?php endif; ?>
		</div>

	</div>
	<div class="card-body mt-5">
		<div class="row">
			
			<div class="col-md-12">
				<div class="col-md-6 group-button">
					<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add POC Link</button>
					<a href="<?php echo e(route('export',Auth::User()->id)); ?>" class="btn btn-secondary">Export CSV</a>
					<a href="<?php echo e(route('samplecsv')); ?>" class="btn btn-warning" >Sample CSV File</a>
					<button type="button" class="btn btn-default" data-toggle="modal" data-target="#myModal1">Import CSV</button>
				</div>     
				<div class="col-md-6 text-right">
					<a href="<?php echo e(route('showloginreports')); ?>" class="btn btn-info" >Show Punchin / Out Time</a>
				</div>
			</div>
		</div>
		<div class="row mt-5">
			<div class="col-md-12">
				<table class="table table-bordered data-table">
					<thead>
						<tr>
							<th>No</th>
							<th>Tracker Date</th>
							<th>Client Name</th>
							<th>Company Name</th>
							<th>Work Done By</th>
							<th>Campaign Name</th>
							<th>POC Links</th>
							<th>Total IP counts</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
		<div id="myModal" class="modal fade p-2" role="dialog">
			<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header text-left">
						<h4 class="modal-title">Add tracker</h4>
					</div>
					<div class="modal-body">
						<div class="card-body">
						<form id="modal-add-tracker-form" class="needs-validation" method="POST" action="<?php echo e(url('/save_link')); ?>" novalidate="novalidate">
							<?php echo csrf_field(); ?> <!-- add csrf field on your form -->
							<div class="modal-header">
								<h5 class="modal-title" id="modal-add-tracker-title">Add Tracker</h5>
								<button type="button" class="btn-close" data-dismiss="modal"></button>
							</div>
							<div class="modal-body">
									
									<input type="hidden" id="user_id" name="user_id" value="<?php echo e(Auth::User()->id); ?>">
									<div class="row">
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label" for="track_date">Tracker Date</label>
												<input type="date" class="form-control valid" id="track_date" name="track_date" placeholder="Tracker date" required="" aria-required="true" aria-invalid="false" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label" for="track_client_name">Client Name</label>
												<select name="track_client_name" id="track_client_name" class="form-control" required="" aria-required="true" required>
													<option value="">--- Select Client ---</option>
													<option value="Intensify">Intensify</option>
													<option value="Integrate">Integrate</option>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label" for="track_company_name">Company Name</label>
												<select name="track_company_name" id="track_company_name" class="form-control" required="" aria-required="true" required>
													<option value="">--- Select Company ---</option>
													<option value="Pangea">Pangea</option>
													<option value="Sales-demand">Sales-demand</option>
													<option value="MarketCode">MarketCode</option>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label" for="track_work_done_by">Work Done By</label>
												<input type="text" class="form-control valid" id="track_work_done_by" name="track_work_done_by" value="<?php echo e(Auth::User()->name); ?>" placeholder="Work Done By" readonly="" required="" aria-required="true" aria-invalid="false" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="mb-3">
												<label class="form-label" for="track_cid">CID</label>
												<input type="text" class="form-control" id="track_cid" name="track_cid" placeholder="CID" required="" aria-required="true" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="mb-3">
												<label class="form-label" for="track_campaign_name">Campaign Name</label>
												<input type="text" class="form-control" id="track_campaign_name" name="track_campaign_name" placeholder="Campaign Name" required="" aria-required="true">
											</div>
										</div>
										<div class="col-md-12">
											<div class="mb-3">
												<label class="form-label" for="track_campaign_name">POC Link</label>
												<input type="text" class="form-control" id="track_poc_link" name="track_poc_link" placeholder="Campaign Name" required="" aria-required="true">
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label" for="track_work_type">Work Type</label>
												<select name="track_work_type" id="track_work_type" class="form-control" required="" aria-required="true">
													<option value="">--- Select Work Type ---</option>
													<option value="New">New</option>
													<option value="Changes">Changes</option>
													<option value="Add Link">Add Link</option>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="mb-3">
												<label class="form-label" for="track_work_status">Work Status</label>
												<select name="track_work_status" id="track_work_status" class="form-control" required="" aria-required="true">
													<option value="">--- Select Work Status ---</option>
													<option value="Completed" selected="">Completed</option>
													<option value="Pending">Pending</option>
												</select>
											</div>
										</div>

										<div class="col-md-12" style="border-top: 1px solid #e5e5e5;margin-top: 20px;">
											<div class="mb-4 pt-4">
												<label class="form-label" for="total_ip">Add total IP count</label>
												<input type="text" class="form-control" id="total_ip" name="total_ip" placeholder="Enter IP Count" aria-required="true" >
											</div>
										</div>

									</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" id="modal-add-tracker-form-btn" class="btn btn-primary waves-effect waves-light">Save changes</button>
							</div>
						</form>
					</div>
					</div>
				</div>

			</div>
		</div>
		<div id="myModal1" class="modal fade p-2" role="dialog">
			<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header text-left">
						<h4 class="modal-title">Import CSV File</h4>
					</div>
					<div class="modal-body">
						<div class="card-body">
						<form id="modal-add-tracker-form" class="needs-validation" method="POST" action="<?php echo e(route('import')); ?>" enctype="multipart/form-data">
							<?php echo csrf_field(); ?> <!-- add csrf field on your form -->
							<div class="modal-body">
									
									<input type="hidden" id="user_id" name="user_id" value="<?php echo e(Auth::User()->id); ?>">
									<div class="row">
										<div class="col-md-12">
											<input type="file" name="file" class="form-control">
										</div>
									</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" id="modal-add-tracker-form-btn" class="btn btn-primary waves-effect waves-light">Import File</button>
							</div>
						</form>
					</div>
					</div>
				</div>

			</div>
		</div>
		
	</div>
</div>
<script type="text/javascript">
  $(function () {
    
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('view_links')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'tracker_date', name: 'tracker_date'},
			{data: 'client_name', name: 'client_name'},
            {data: 'company_name', name: 'company_name'},
            {data: 'work_done', name: 'work_done'},
            {data: 'camp_name', name: 'camp_name'},
            {data: 'poc_links', name: 'poc_links'},
			{data: 'ip_counts', name: 'ip_counts'},
        ]
    });
    
  });
</script>
<script>
	$( "#punchin" ).on( "click", function() {
		$(this).prop("disabled", true);
	} );
   function exportTasks(_this) {
      let _url = $(_this).data('href');
      window.location.href = _url;
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pgs-hrms\resources\views/dashboard.blade.php ENDPATH**/ ?>