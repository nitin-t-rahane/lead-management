

<?php $__env->startSection('content'); ?>
<style>
	.card-header img{
		padding-top: 10px;
		padding-bottom: 10px;
	}
	.card-header{
		background: #fff;
		border-bottom: 0px !important;
	}
	
</style>
<?php if($message = Session::get('success')): ?>

<div class="alert alert-info">
<?php echo e($message); ?>

</div>

<?php endif; ?>

<div class="row justify-content-center">
	<div class="col-md-4">
		<div class="card text-center">
			<div class="card-header">
				<img src="<?php echo e(asset('img/logo.png')); ?>" width="100">
			</div>
			<div class="card-body">
				<form action="<?php echo e(route('validate_login')); ?>" method="post">
					<?php echo csrf_field(); ?>
					<div class="form-group text-left mb-4">
						<label for="email_address">Enter User Name</label>
						<input type="text" name="email_address" class="form-control" placeholder="Email" />
						<?php if($errors->has('email')): ?>
							<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
						<?php endif; ?>
					</div>
					<div class="form-group text-left mb-5">
						<label for="password">Enter Password</label>
						<input type="password" name="password" class="form-control" placeholder="Password" />
						<?php if($errors->has('password')): ?>
							<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
						<?php endif; ?>
					</div>
					<div class="d-grid mx-auto mb-5">
						<button type="subit" class="btn btn-dark btn-block">Login</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lead-management\resources\views/login.blade.php ENDPATH**/ ?>